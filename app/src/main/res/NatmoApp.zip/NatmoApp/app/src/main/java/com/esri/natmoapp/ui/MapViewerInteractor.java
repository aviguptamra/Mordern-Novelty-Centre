package com.esri.natmoapp.ui;

public interface MapViewerInteractor {
}
